CREATE TABLE `bookings` (
	`id` text PRIMARY KEY NOT NULL,
	`tran_id` text NOT NULL,
	`guest_name` text NOT NULL,
	`address` text NOT NULL,
	`booking_type` text NOT NULL,
	`company` text,
	`room` text NOT NULL,
	`guests` text NOT NULL,
	`check_in` text NOT NULL,
	`check_out` text NOT NULL,
	`rate_cents` integer NOT NULL,
	`deposit_cents` integer NOT NULL,
	`amount_cents` integer NOT NULL,
	`currency` text DEFAULT 'USD' NOT NULL,
	`booking_status` text DEFAULT 'PAYMENT_PENDING' NOT NULL,
	`payment_status` text DEFAULT 'PAYMENT_PENDING' NOT NULL,
	`apv` text,
	`created_at` integer NOT NULL,
	`updated_at` integer NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `bookings_tran_id_unique` ON `bookings` (`tran_id`);
--> statement-breakpoint
CREATE TABLE `payment_events` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`tran_id` text NOT NULL,
	`payload_hash` text NOT NULL,
	`status` text NOT NULL,
	`apv` text,
	`received_at` integer NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `payment_events_payload_hash_unique` ON `payment_events` (`payload_hash`);

export default {
  "bootstrapScriptContent": "import(\"/assets/index-BPwhTk29.js\")",
  "clientReferenceDeps": {
    "6efdf509a785": {
      "js": [
        "/assets/page-BHNWUOc3.js",
        "/assets/rolldown-runtime-S-ySWqyJ.js",
        "/assets/framework-DjPHiq1u.js",
        "/assets/index-BPwhTk29.js"
      ],
      "css": []
    },
    "d041429ec63f": {
      "js": [
        "/assets/index-BPwhTk29.js",
        "/assets/rolldown-runtime-S-ySWqyJ.js",
        "/assets/framework-DjPHiq1u.js"
      ],
      "css": []
    },
    "e562e7309659": {
      "js": [
        "/assets/layout-segment-context-4AZrPKlt.js",
        "/assets/rolldown-runtime-S-ySWqyJ.js",
        "/assets/index-BPwhTk29.js",
        "/assets/framework-DjPHiq1u.js"
      ],
      "css": []
    },
    "8a1c26e77cc3": {
      "js": [
        "/assets/index-BPwhTk29.js",
        "/assets/rolldown-runtime-S-ySWqyJ.js",
        "/assets/framework-DjPHiq1u.js"
      ],
      "css": []
    }
  },
  "serverResources": {
    "app/layout.tsx": {
      "js": [],
      "css": [
        "/assets/index-CMmUiais.css"
      ]
    }
  }
}
import { a as require_react, o as __toESM, t as require_jsx_runtime } from "../index.js";
//#region app/page.tsx
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
var import_jsx_runtime = require_jsx_runtime();
var initial = {
	guestName: "",
	address: "Cambodia",
	bookingType: "Personal",
	company: "",
	room: "",
	guests: "1 Adult",
	checkIn: "2026-07-19T13:00",
	checkOut: "2026-07-21T11:00",
	rate: "33.00",
	deposit: "0.00"
};
var money = (value) => value.toLocaleString("en-US", {
	minimumFractionDigits: 2,
	maximumFractionDigits: 2
});
var displayDate = (value) => value ? new Intl.DateTimeFormat("en-US", {
	month: "short",
	day: "2-digit",
	year: "numeric",
	hour: "2-digit",
	minute: "2-digit"
}).format(new Date(value)) : "—";
var shortDate = (value) => value ? new Intl.DateTimeFormat("en-US", {
	month: "short",
	day: "2-digit",
	year: "numeric"
}).format(new Date(value)) : "—";
function Home() {
	const [form, setForm] = (0, import_react.useState)(initial);
	const [invoice, setInvoice] = (0, import_react.useState)(null);
	const [confirmation, setConfirmation] = (0, import_react.useState)("");
	const [message, setMessage] = (0, import_react.useState)("");
	const [bookingStatus, setBookingStatus] = (0, import_react.useState)("DRAFT");
	const [paymentMessage, setPaymentMessage] = (0, import_react.useState)("");
	const [checkoutRequest, setCheckoutRequest] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		const params = new URLSearchParams(window.location.search);
		const packageName = params.get("packageName")?.trim();
		const price = Number(params.get("price"));
		if (!packageName) return;
		setForm((current) => ({
			...current,
			bookingType: "Package Tours",
			company: packageName.slice(0, 160),
			rate: Number.isFinite(price) && price > 0 ? price.toFixed(2) : current.rate
		}));
	}, []);
	const calculateStay = (checkIn, checkOut) => {
		if (!checkIn || !checkOut) return 0;
		const start = new Date(checkIn);
		const end = new Date(checkOut);
		if (end <= start) return 0;
		const startDay = new Date(start.getFullYear(), start.getMonth(), start.getDate());
		const endDay = new Date(end.getFullYear(), end.getMonth(), end.getDate());
		return Math.max(1, Math.round((endDay.getTime() - startDay.getTime()) / 864e5));
	};
	const nights = calculateStay(form.checkIn, form.checkOut);
	const totals = (0, import_react.useMemo)(() => {
		const charges = (Number(form.rate) || 0) * calculateStay(form.checkIn, form.checkOut);
		const paid = Number(form.deposit) || 0;
		return {
			charges,
			paid,
			balance: Math.max(charges - paid, 0)
		};
	}, [form]);
	const update = (key, value) => setForm((prev) => ({
		...prev,
		[key]: value
	}));
	const makeInvoice = (event) => {
		event.preventDefault();
		if (nights === 0) {
			setMessage("Please select a check-out time later than check-in.");
			return;
		}
		setInvoice({ ...form });
		setBookingStatus("PAYMENT_PENDING");
		setCheckoutRequest(null);
		setPaymentMessage("");
		setMessage("វិក្កយបត្របានបង្កើតដោយជោគជ័យ • Invoice created successfully");
		setTimeout(() => document.getElementById("invoice")?.scrollIntoView({ behavior: "smooth" }), 50);
		openHostedCheckout(form);
	};
	const invoiceTotals = invoice ? {
		charges: Number(invoice.rate) * calculateStay(invoice.checkIn, invoice.checkOut),
		deposit: Number(invoice.deposit)
	} : null;
	const submitHostedForm = (request) => {
		const paymentForm = document.createElement("form");
		paymentForm.method = "POST";
		paymentForm.action = request.action;
		paymentForm.target = "payway_checkout";
		Object.entries(request.fields).forEach(([name, value]) => {
			const input = document.createElement("input");
			input.type = "hidden";
			input.name = name;
			input.value = value;
			paymentForm.appendChild(input);
		});
		document.body.appendChild(paymentForm);
		paymentForm.submit();
		paymentForm.remove();
	};
	const openHostedCheckout = async (booking) => {
		const checkoutWindow = window.open("", "payway_checkout", "width=520,height=760");
		if (!checkoutWindow) {
			setPaymentMessage("Please allow pop-ups, then choose Continue Payment.");
			return;
		}
		checkoutWindow.document.write("<title>Opening ABA PayWay…</title><p style='font-family:Arial;padding:32px'>Preparing secure ABA PayWay checkout…</p>");
		try {
			if (!booking && checkoutRequest) {
				submitHostedForm(checkoutRequest);
				return;
			}
			const bookingToPay = booking ?? invoice ?? form;
			const response = await fetch(`${process.env.NEXT_PUBLIC_API_BASE_URL}/api/payway/purchase`, {
				method: "POST",
				headers: { "Content-Type": "application/json" },
				body: JSON.stringify(bookingToPay)
			});
			const result = await response.json();
			if (!response.ok) throw new Error(result.message || "PayWay is not configured.");
			if (!result.action || !result.fields) throw new Error("Invalid PayWay checkout response.");
			const nextCheckout = {
				action: result.action,
				fields: result.fields
			};
			setConfirmation(result.bookingId);
			setBookingStatus(result.status || "PAYMENT_PENDING");
			setCheckoutRequest(nextCheckout);
			submitHostedForm(nextCheckout);
		} catch (error) {
			checkoutWindow.close();
			setPaymentMessage(error instanceof Error ? error.message : "Unable to start PayWay checkout.");
		}
	};
	const checkPaymentStatus = async () => {
		setPaymentMessage("Checking payment status…");
		try {
			const result = await (await fetch(`/api/payway/status?bookingId=${encodeURIComponent(confirmation)}`)).json();
			setBookingStatus(result.status || "PAYMENT_PENDING");
			setPaymentMessage(result.message || "Payment is still pending.");
		} catch {
			setPaymentMessage("Unable to check payment status. Please try again.");
		}
	};
	const cancelBooking = async () => {
		if (bookingStatus === "PAID" || bookingStatus === "CONFIRMED") return;
		try {
			const response = await fetch("/api/payway/cancel", {
				method: "POST",
				headers: { "Content-Type": "application/json" },
				body: JSON.stringify({ bookingId: confirmation })
			});
			const result = await response.json();
			if (!response.ok) throw new Error(result.message || "Unable to cancel booking.");
			setBookingStatus(result.status || "CANCELLED");
			setPaymentMessage(result.message || "Booking cancelled.");
		} catch (error) {
			setPaymentMessage(error instanceof Error ? error.message : "Unable to cancel booking.");
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
			className: "appHeader noPrint",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					className: "brandArtwork",
					src: "/prathna-kasekor-khmer-logo.png",
					alt: "PRATHNA KASEKOR KHMER IMPORT EXPORT CO., LTD."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "eyebrow",
						children: "PRATHNA KASEKOR KHMER IMPORT EXPORT CO., LTD."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", { children: "Booking & Invoice" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "khmer",
						children: "ប្រព័ន្ធកក់បន្ទប់ និងវិក្កយបត្រ"
					})
				] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "status",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", {}), " System ready"]
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "workspace noPrint",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "intro",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "NEW RESERVATION" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "Create New Booking" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Enter guest details and charges. Your total updates automatically." })
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "totalPill",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("small", { children: "BALANCE DUE" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("strong", { children: ["USD ", money(totals.balance)] })]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					onSubmit: makeInvoice,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "formGrid",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("legend", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "01" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["GUEST PROFILE", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("small", { children: "ព័ត៌មានភ្ញៀវ" })] })] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", { children: [
									"Guest name ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("em", { children: "ឈ្មោះភ្ញៀវ" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										required: true,
										value: form.guestName,
										onChange: (e) => update("guestName", e.target.value),
										placeholder: "e.g. Chang Lung Ng"
									})
								] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", { children: [
									"Address / Country ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("em", { children: "អាសយដ្ឋាន / ប្រទេស" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										required: true,
										value: form.address,
										onChange: (e) => update("address", e.target.value)
									})
								] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", { children: [
									"Booking type ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("em", { children: "ប្រភេទការកក់" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
										value: form.bookingType,
										onChange: (e) => update("bookingType", e.target.value),
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "Personal" }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "Family" }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "Company" }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "Package Tours" })
										]
									})
								] }),
								(form.bookingType === "Company" || form.bookingType === "Package Tours") && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", { children: [
									"Company / Tour name ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("em", { children: "ឈ្មោះក្រុមហ៊ុន / ទេសចរណ៍" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										value: form.company,
										onChange: (e) => update("company", e.target.value),
										placeholder: "Enter organization name"
									})
								] })
							] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("legend", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "02" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["RESERVATION DETAILS", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("small", { children: "ព័ត៌មានការកក់" })] })] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "two",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", { children: [
										"Room number ",
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("em", { children: "លេខបន្ទប់" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											required: true,
											value: form.room,
											onChange: (e) => update("room", e.target.value),
											placeholder: "310"
										})
									] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", { children: [
										"Guests ",
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("em", { children: "ចំនួនភ្ញៀវ" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
											value: form.guests,
											onChange: (e) => update("guests", e.target.value),
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "1 Adult" }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "2 Adults" }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "Family" })
											]
										})
									] })]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", { children: [
									"Check-in ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("em", { children: "ថ្ងៃចូល" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										required: true,
										type: "datetime-local",
										value: form.checkIn,
										onChange: (e) => update("checkIn", e.target.value)
									})
								] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", { children: [
									"Check-out ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("em", { children: "ថ្ងៃចេញ" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										required: true,
										type: "datetime-local",
										value: form.checkOut,
										onChange: (e) => update("checkOut", e.target.value)
									})
								] })
							] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", {
								className: "charges",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("legend", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "03" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["CHARGES & PAYMENT", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("small", { children: "ការគិតថ្លៃ និងការទូទាត់" })] })] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "three",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", { children: ["Daily accommodation rate", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
												required: true,
												min: "0",
												step: "0.01",
												type: "number",
												value: form.rate,
												onChange: (e) => update("rate", e.target.value)
											})] }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", { children: [
												"Length of stay ",
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("em", { children: "Auto" }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
													className: "autoField",
													readOnly: true,
													value: `${nights} ${nights === 1 ? "day" : "days"}`
												})
											] }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", { children: ["Paid / Deposit", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
												min: "0",
												step: "0.01",
												max: totals.charges || void 0,
												type: "number",
												value: form.deposit,
												onChange: (e) => update("deposit", e.target.value)
											})] })
										]
									}),
									form.checkIn && form.checkOut && nights === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "dateError",
										children: "Check-out must be later than check-in."
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "summary",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["Total charges ", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("b", { children: ["USD ", money(totals.charges)] })] }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["Paid / deposit ", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("b", { children: ["USD ", money(totals.paid)] })] }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "due",
												children: ["Balance due ", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("b", { children: ["USD ", money(totals.balance)] })]
											})
										]
									})
								]
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						className: "primary",
						type: "submit",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Confirm Booking" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("small", { children: "បញ្ជាក់ការកក់ និងបន្តទៅការទូទាត់" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "→" })
						]
					})]
				}),
				message && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "toast",
					role: "status",
					children: ["✓ ", message]
				})
			]
		}),
		invoice && invoiceTotals && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "invoiceWrap",
			id: "invoice",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: "invoice",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "companyHeader",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								className: "invoiceCompanyLogo",
								src: "/prathna-kasekor-khmer-logo.png",
								alt: "PRATHNA KASEKOR KHMER IMPORT EXPORT CO., LTD."
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "PRATHNA KASEKOR KHMER IMPORT EXPORT CO., LTD." }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "Address (EN):" }), " No House Number, No Street Name, Kilometre 4 Village, Sangkat Phsar Kandal, Poipet Municipality, Banteay Meanchey Province, Cambodia"] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "khmer",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "អាសយដ្ឋាន (KH):" }), " ភូមិគីឡូម៉ែត្រលេខ៤ សង្កាត់ផ្សារកណ្ដាល ក្រុងប៉ោយប៉ែត ខេត្តបន្ទាយមានជ័យ"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "Email:" }),
									" chhimrasmey82@gmail.com \xA0|\xA0 ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "Tel:" }),
									" +855 67 919 919 \xA0|\xA0 ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "Website:" }),
									" www.ptrconnect.online"
								] })
							] })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "invoiceTitle",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "CUSTOMER INVOICE" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("small", { children: "វិក្កយបត្រអតិថិជន" })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("small", { children: "CONFIRMATION NO." }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: confirmation })] })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "profileGrid",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "infoBox",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", { children: "GUEST PROFILE" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "Guest Name:" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: invoice.guestName })] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "Address:" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: invoice.address })] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "Booking Type:" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: invoice.bookingType })] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "Company / Tour:" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: invoice.company || "—" })] })
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "infoBox",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", { children: "RESERVATION DETAILS" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "Room Number:" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: invoice.room })] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "No. of Guests:" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: invoice.guests })] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "Check-In:" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: displayDate(invoice.checkIn) })] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "Check-Out:" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: displayDate(invoice.checkOut) })] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "Length of Stay:" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [calculateStay(invoice.checkIn, invoice.checkOut), " days"] })] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "Status:" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: bookingStatus === "CONFIRMED" ? "confirmed" : "pending",
										children: bookingStatus.replaceAll("_", " ")
									})] })
								]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "DATE" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "DESCRIPTION" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "CHARGES (USD)" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "CREDITS / PAYMENTS (USD)" })
						] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tbody", { children: [Array.from({ length: calculateStay(invoice.checkIn, invoice.checkOut) || 1 }).map((_, i) => {
							const date = new Date(invoice.checkIn);
							date.setDate(date.getDate() + i);
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: shortDate(date.toISOString()) }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", { children: ["Accommodation Charges — Room #", invoice.room] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: money(Number(invoice.rate)) }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: "0.00" })
							] }, i);
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: "—" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: "Occupancy Tax (0.00%)" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: "0.00" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: "0.00" })
						] })] })] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "totals",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Total Charges" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: money(invoiceTotals.charges) })] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Paid / Deposit" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: money(invoiceTotals.deposit) })] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "balance",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Balance to Pay" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("b", { children: ["USD ", money(Math.max(invoiceTotals.charges - invoiceTotals.deposit, 0))] })]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "notice",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "NOTICE TO GUESTS:" }), " This property is privately owned and management reserves the right to refuse service. Management will not be responsible for loss of money, jewellery or valuables of any kind, or for items left in the room."] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "CHECKOUT TIME: 11:00 AM \xA0|\xA0 SELF REGISTRATION ONLY" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
								"I agree that my liability for this bill is not waived and agree to be held personally liable for all charges, including missing or damaged items."
							] })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "signatures",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {}), "Guest Signature"] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {}), "Authorized Representative"] })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", { children: ["Thank you for choosing PRATHNA KASEKOR KHMER IMPORT EXPORT CO., LTD. ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "Page 1" })] })
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "invoiceActions bottomActions noPrint",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: () => window.print(),
							children: "Print / Save PDF"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: () => void openHostedCheckout(),
							children: "Continue Payment"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							className: "ghost",
							onClick: () => void checkPaymentStatus(),
							children: "Check Payment Status"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							className: "danger",
							disabled: bookingStatus === "PAID" || bookingStatus === "CONFIRMED" || bookingStatus === "CANCELLED",
							onClick: cancelBooking,
							children: "Cancel Booking"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							className: "ghost",
							onClick: () => setInvoice(null),
							children: "Close"
						})
					]
				}),
				paymentMessage && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "paymentMessage noPrint",
					children: paymentMessage
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "paywayRule noPrint",
					children: "Payment methods and official logos are displayed by ABA PayWay Hosted Checkout according to the merchant account settings."
				})
			]
		})
	] });
}
//#endregion
export { Home as default };

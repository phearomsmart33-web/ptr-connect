import { env } from "cloudflare:workers";

export type StoredBooking = {
  id: string;
  tran_id: string;
  amount_cents: number;
  currency: string;
  booking_status: string;
  payment_status: string;
  apv: string | null;
};

function db() {
  if (!env.DB) throw new Error("DATABASE_NOT_CONFIGURED");
  return env.DB;
}

export async function createBooking(input: {
  id: string; tranId: string; guestName: string; address: string; bookingType: string; company?: string;
  room: string; guests: string; checkIn: string; checkOut: string; rateCents: number; depositCents: number;
  amountCents: number; currency: string;
}) {
  const now = Date.now();
  await db().prepare(`INSERT INTO bookings (
    id, tran_id, guest_name, address, booking_type, company, room, guests, check_in, check_out,
    rate_cents, deposit_cents, amount_cents, currency, booking_status, payment_status, created_at, updated_at
  ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'PAYMENT_PENDING', 'PAYMENT_PENDING', ?, ?)`)
    .bind(input.id, input.tranId, input.guestName, input.address, input.bookingType, input.company || null,
      input.room, input.guests, input.checkIn, input.checkOut, input.rateCents, input.depositCents,
      input.amountCents, input.currency, now, now).run();
}

export async function findBookingById(id: string): Promise<StoredBooking | null> {
  return db().prepare("SELECT id, tran_id, amount_cents, currency, booking_status, payment_status, apv FROM bookings WHERE id = ?")
    .bind(id).first<StoredBooking>();
}

export async function findBookingByTransaction(tranId: string): Promise<StoredBooking | null> {
  return db().prepare("SELECT id, tran_id, amount_cents, currency, booking_status, payment_status, apv FROM bookings WHERE tran_id = ?")
    .bind(tranId).first<StoredBooking>();
}

export async function recordPaymentResult(input: {
  tranId: string; payloadHash: string; paymentStatus: string; bookingStatus: string; apv?: string | null;
}) {
  const now = Date.now();
  await db().batch([
    db().prepare("INSERT OR IGNORE INTO payment_events (tran_id, payload_hash, status, apv, received_at) VALUES (?, ?, ?, ?, ?)")
      .bind(input.tranId, input.payloadHash, input.paymentStatus, input.apv || null, now),
    db().prepare("UPDATE bookings SET payment_status = ?, booking_status = ?, apv = COALESCE(?, apv), updated_at = ? WHERE tran_id = ?")
      .bind(input.paymentStatus, input.bookingStatus, input.apv || null, now, input.tranId),
  ]);
}

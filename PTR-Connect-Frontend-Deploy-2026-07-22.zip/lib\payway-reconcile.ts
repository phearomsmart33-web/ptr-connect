import { findBookingByTransaction, recordPaymentResult, type StoredBooking } from "./booking-store";
import { checkTransactionHash, utcRequestTime } from "./payway";
import { getPayWayConfig } from "./payway-config";

type CheckResponse = {
  data?: {
    payment_status_code?: number;
    payment_status?: string;
    payment_amount?: number;
    total_amount?: number;
    payment_currency?: string;
    apv?: string;
  };
  status?: { code?: string; message?: string; tran_id?: string } | number;
  description?: string;
  amount?: number;
  totalAmount?: number;
  original_currency?: string;
  apv?: string;
};

export async function checkPayWayTransaction(booking: StoredBooking) {
  const config = getPayWayConfig();
  const reqTime = utcRequestTime();
  const hash = await checkTransactionHash(reqTime, config.merchantId, booking.tran_id, config.apiKey);
  const response = await fetch(`${config.baseUrl}/api/payment-gateway/v1/payments/check-transaction-2`, {
    method: "POST",
    headers: { "Content-Type": "application/json", Accept: "application/json", Referer: new URL(config.callbackUrl).origin + "/" },
    body: JSON.stringify({ req_time: reqTime, merchant_id: config.merchantId, tran_id: booking.tran_id, hash }),
  });
  if (!response.ok) throw new Error("PAYWAY_CHECK_UNAVAILABLE");
  const result = await response.json() as CheckResponse;
  const approved = result.data?.payment_status_code === 0 ||
    (typeof result.status === "number" && result.status === 0) ||
    result.data?.payment_status === "APPROVED";
  const amount = result.data?.payment_amount ?? result.data?.total_amount ?? result.totalAmount ?? result.amount;
  const currency = result.data?.payment_currency ?? result.original_currency;
  const amountMatches = typeof amount === "number" && Math.round(amount * 100) === booking.amount_cents;
  const currencyMatches = currency === booking.currency;
  const apv = result.data?.apv ?? result.apv ?? null;

  let paymentStatus = "PAYMENT_PENDING";
  let bookingStatus = "PAYMENT_PENDING";
  if (approved && (!amountMatches || !currencyMatches)) {
    paymentStatus = "REVIEW_REQUIRED";
    bookingStatus = "REVIEW_REQUIRED";
  } else if (approved) {
    paymentStatus = "PAID";
    bookingStatus = "CONFIRMED";
  } else {
    const pending = result.data?.payment_status === "PENDING" || result.status === 1 || result.status === 2;
    paymentStatus = pending ? "PAYMENT_PENDING" : "PAYMENT_FAILED";
    bookingStatus = paymentStatus;
  }
  return { paymentStatus, bookingStatus, apv, raw: result };
}

export async function reconcileTransaction(tranId: string, eventHash: string) {
  const booking = await findBookingByTransaction(tranId);
  if (!booking) throw new Error("BOOKING_NOT_FOUND");
  if (booking.booking_status === "CONFIRMED" && booking.payment_status === "PAID") return booking;
  const checked = await checkPayWayTransaction(booking);
  await recordPaymentResult({
    tranId, payloadHash: eventHash, paymentStatus: checked.paymentStatus,
    bookingStatus: checked.bookingStatus, apv: checked.apv,
  });
  return { ...booking, booking_status: checked.bookingStatus, payment_status: checked.paymentStatus, apv: checked.apv };
}

import { NextRequest, NextResponse } from "next/server";
import { findBookingById } from "../../../../lib/booking-store";
import { reconcileTransaction } from "../../../../lib/payway-reconcile";

export async function GET(request: NextRequest) {
  try {
    const bookingId = request.nextUrl.searchParams.get("bookingId");
    if (!bookingId) return NextResponse.json({ message: "Missing booking ID." }, { status: 400 });
    let booking = await findBookingById(bookingId);
    if (!booking) return NextResponse.json({ message: "Booking not found." }, { status: 404 });
    if (booking.payment_status === "PAYMENT_PENDING") {
      booking = await reconcileTransaction(booking.tran_id, `STATUS-${booking.tran_id}-${Date.now()}`);
    }
    return NextResponse.json({
      bookingId: booking.id,
      status: booking.booking_status,
      paymentStatus: booking.payment_status,
      message: booking.booking_status === "CONFIRMED" ? "Payment verified. Booking confirmed." : `Booking status: ${booking.booking_status}`,
    });
  } catch (error) {
    const code = error instanceof Error ? error.message : "STATUS_CHECK_FAILED";
    return NextResponse.json({ code, message: "Unable to verify payment status right now." }, { status: 503 });
  }
}

import { NextRequest, NextResponse } from "next/server";
import { createBooking } from "../../../../lib/booking-store";
import {
  base64Utf8,
  calculateStay,
  normalizeMoney,
  purchaseHash,
  safeTransactionId,
  utcRequestTime,
} from "../../../../lib/payway";
import { getPayWayConfig } from "../../../../lib/payway-config";

type BookingRequest = {
  guestName?: string; address?: string; bookingType?: string; company?: string; room?: string;
  guests?: string; checkIn?: string; checkOut?: string; rate?: string | number; deposit?: string | number;
};

function requiredText(value: unknown, name: string, max = 120): string {
  if (typeof value !== "string" || !value.trim() || value.trim().length > max) throw new Error(`INVALID_${name}`);
  return value.trim();
}

export async function POST(request: NextRequest) {
  try {
    const config = getPayWayConfig();
    const body = await request.json() as BookingRequest;
    const guestName = requiredText(body.guestName, "GUEST_NAME");
    const address = requiredText(body.address, "ADDRESS");
    const bookingType = requiredText(body.bookingType, "BOOKING_TYPE", 40);
    const room = requiredText(body.room, "ROOM", 30);
    const guests = requiredText(body.guests, "GUESTS", 40);
    const checkIn = requiredText(body.checkIn, "CHECK_IN", 40);
    const checkOut = requiredText(body.checkOut, "CHECK_OUT", 40);
    const stay = calculateStay(checkIn, checkOut);
    const rateCents = normalizeMoney(body.rate);
    const depositCents = normalizeMoney(body.deposit ?? 0);
    const chargeCents = rateCents * stay;
    if (rateCents <= 0 || depositCents > chargeCents) throw new Error("INVALID_BOOKING_AMOUNT");
    const amountCents = chargeCents - depositCents;
    if (amountCents <= 0) throw new Error("NO_BALANCE_DUE");

    const tranId = safeTransactionId();
    const bookingId = `PKK-${tranId}`;
    const reqTime = utcRequestTime();
    const amount = (amountCents / 100).toFixed(2);
    const nameParts = guestName.replace(/[^\p{L}\p{N}\s'-]/gu, "").trim().split(/\s+/);
    const firstname = (nameParts.shift() || "Guest").slice(0, 20);
    const lastname = (nameParts.join(" ") || "Customer").slice(0, 20);
    const items = base64Utf8(JSON.stringify([{ name: `Room ${room} accommodation`, quantity: 1, price: amount }]));
    const returnUrl = base64Utf8(config.callbackUrl);

    const fields: Record<string, string> = {
      req_time: reqTime,
      merchant_id: config.merchantId,
      tran_id: tranId,
      firstname,
      lastname,
      amount,
      type: "purchase",
      payment_option: "",
      items,
      currency: "USD",
      return_url: returnUrl,
      continue_success_url: config.successUrl,
      return_params: bookingId,
      view_type: "hosted_view",
    };
    fields.hash = await purchaseHash(fields, config.apiKey);

    await createBooking({
      id: bookingId, tranId, guestName, address, bookingType, company: body.company?.trim(), room, guests,
      checkIn, checkOut, rateCents, depositCents, amountCents, currency: "USD",
    });

    return NextResponse.json({
      bookingId,
      tranId,
      status: "PAYMENT_PENDING",
      action: `${config.baseUrl}/api/payment-gateway/v1/payments/purchase`,
      fields,
    });
  } catch (error) {
    const code = error instanceof Error ? error.message : "PAYWAY_PURCHASE_FAILED";
    const configurationError = code === "PAYWAY_NOT_CONFIGURED" || code === "DATABASE_NOT_CONFIGURED";
    return NextResponse.json(
      { code, message: configurationError ? "Payment service configuration is incomplete. No payment was attempted." : "Unable to create this payment request." },
      { status: configurationError ? 503 : 400 },
    );
  }
}

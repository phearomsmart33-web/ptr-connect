import { integer, sqliteTable, text, uniqueIndex } from "drizzle-orm/sqlite-core";

export const bookings = sqliteTable(
  "bookings",
  {
    id: text("id").primaryKey(),
    tranId: text("tran_id").notNull(),
    guestName: text("guest_name").notNull(),
    address: text("address").notNull(),
    bookingType: text("booking_type").notNull(),
    company: text("company"),
    room: text("room").notNull(),
    guests: text("guests").notNull(),
    checkIn: text("check_in").notNull(),
    checkOut: text("check_out").notNull(),
    rateCents: integer("rate_cents").notNull(),
    depositCents: integer("deposit_cents").notNull(),
    amountCents: integer("amount_cents").notNull(),
    currency: text("currency").notNull().default("USD"),
    bookingStatus: text("booking_status").notNull().default("PAYMENT_PENDING"),
    paymentStatus: text("payment_status").notNull().default("PAYMENT_PENDING"),
    apv: text("apv"),
    createdAt: integer("created_at").notNull(),
    updatedAt: integer("updated_at").notNull(),
  },
  (table) => [uniqueIndex("bookings_tran_id_unique").on(table.tranId)],
);

export const paymentEvents = sqliteTable(
  "payment_events",
  {
    id: integer("id").primaryKey({ autoIncrement: true }),
    tranId: text("tran_id").notNull(),
    payloadHash: text("payload_hash").notNull(),
    status: text("status").notNull(),
    apv: text("apv"),
    receivedAt: integer("received_at").notNull(),
  },
  (table) => [uniqueIndex("payment_events_payload_hash_unique").on(table.payloadHash)],
);

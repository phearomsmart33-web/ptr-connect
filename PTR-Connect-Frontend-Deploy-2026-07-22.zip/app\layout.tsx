import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Booking & Invoice | PRATHNA KASEKOR KHMER IMPORT EXPORT CO., LTD.",
  description: "Official booking, invoice, and ABA PayWay payment system for PRATHNA KASEKOR KHMER IMPORT EXPORT CO., LTD.",
  icons: {
    icon: "/prathna-kasekor-khmer-logo.png",
    apple: "/prathna-kasekor-khmer-logo.png",
  },
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="km"><body>{children}</body></html>;
}

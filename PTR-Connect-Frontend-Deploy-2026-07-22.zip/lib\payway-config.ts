import { env } from "cloudflare:workers";

export type PayWayConfig = {
  merchantId: string;
  apiKey: string;
  baseUrl: string;
  callbackUrl: string;
  successUrl: string;
};

const runtimeEnv = env as unknown as Record<string, string | undefined>;

function readEnv(name: string): string {
  return runtimeEnv[name] || process.env[name] || "";
}

export function getPayWayConfig(): PayWayConfig {
  const merchantId = readEnv("PAYWAY_MERCHANT_ID");
  const apiKey = readEnv("PAYWAY_API_KEY");
  const baseUrl = readEnv("PAYWAY_BASE_URL") || "https://checkout-sandbox.payway.com.kh";
  const callbackUrl = readEnv("PAYWAY_CALLBACK_URL") || "https://booking.ptrconnect.online/api/payway/pushback";
  const successUrl = readEnv("PAYWAY_SUCCESS_URL") || "https://booking.ptrconnect.online/?payment=complete";

  if (!merchantId || !apiKey) throw new Error("PAYWAY_NOT_CONFIGURED");
  if (!baseUrl.startsWith("https://") || !callbackUrl.startsWith("https://") || !successUrl.startsWith("https://")) {
    throw new Error("PAYWAY_INVALID_URL_CONFIG");
  }
  return { merchantId, apiKey, baseUrl: baseUrl.replace(/\/$/, ""), callbackUrl, successUrl };
}

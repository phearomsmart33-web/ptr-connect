"use client";

import { FormEvent, useEffect, useMemo, useState } from "react";

type Booking = {
  guestName: string; address: string; bookingType: string; company: string; room: string;
  guests: string; checkIn: string; checkOut: string; rate: string;
  deposit: string;
};

type CheckoutRequest = { action: string; fields: Record<string, string> };

const initial: Booking = {
  guestName: "", address: "Cambodia", bookingType: "Personal", company: "", room: "",
  guests: "1 Adult", checkIn: "2026-07-19T13:00", checkOut: "2026-07-21T11:00",
  rate: "33.00", deposit: "0.00",
};

const money = (value: number) => value.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const displayDate = (value: string) => value ? new Intl.DateTimeFormat("en-US", { month: "short", day: "2-digit", year: "numeric", hour: "2-digit", minute: "2-digit" }).format(new Date(value)) : "—";
const shortDate = (value: string) => value ? new Intl.DateTimeFormat("en-US", { month: "short", day: "2-digit", year: "numeric" }).format(new Date(value)) : "—";

export default function Home() {
  const [form, setForm] = useState<Booking>(initial);
  const [invoice, setInvoice] = useState<Booking | null>(null);
  const [confirmation, setConfirmation] = useState("");
  const [message, setMessage] = useState("");
  const [bookingStatus, setBookingStatus] = useState("DRAFT");
  const [paymentMessage, setPaymentMessage] = useState("");
  const [checkoutRequest, setCheckoutRequest] = useState<CheckoutRequest | null>(null);

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const packageName = params.get("packageName")?.trim();
    const price = Number(params.get("price"));
    if (!packageName) return;
    setForm(current => ({
      ...current,
      bookingType: "Package Tours",
      company: packageName.slice(0, 160),
      rate: Number.isFinite(price) && price > 0 ? price.toFixed(2) : current.rate,
    }));
  }, []);
  const calculateStay = (checkIn: string, checkOut: string) => {
    if (!checkIn || !checkOut) return 0;
    const start = new Date(checkIn);
    const end = new Date(checkOut);
    if (end <= start) return 0;
    const startDay = new Date(start.getFullYear(), start.getMonth(), start.getDate());
    const endDay = new Date(end.getFullYear(), end.getMonth(), end.getDate());
    return Math.max(1, Math.round((endDay.getTime() - startDay.getTime()) / 86400000));
  };
  const nights = calculateStay(form.checkIn, form.checkOut);

  const totals = useMemo(() => {
    const charges = (Number(form.rate) || 0) * calculateStay(form.checkIn, form.checkOut);
    const paid = Number(form.deposit) || 0;
    return { charges, paid, balance: Math.max(charges - paid, 0) };
  }, [form]);

  const update = (key: keyof Booking, value: string) => setForm(prev => ({ ...prev, [key]: value }));
  const makeInvoice = (event: FormEvent) => {
    event.preventDefault();
    if (nights === 0) {
      setMessage("Please select a check-out time later than check-in.");
      return;
    }
    setInvoice({ ...form });
    setBookingStatus("PAYMENT_PENDING");
    setCheckoutRequest(null);
    setPaymentMessage("");
    setMessage("វិក្កយបត្របានបង្កើតដោយជោគជ័យ • Invoice created successfully");
    setTimeout(() => document.getElementById("invoice")?.scrollIntoView({ behavior: "smooth" }), 50);
    void openHostedCheckout(form);
  };

  const invoiceTotals = invoice ? {
    charges: Number(invoice.rate) * calculateStay(invoice.checkIn, invoice.checkOut),
    deposit: Number(invoice.deposit),
  } : null;

  const submitHostedForm = (request: CheckoutRequest) => {
    const paymentForm = document.createElement("form");
    paymentForm.method = "POST";
    paymentForm.action = request.action;
    paymentForm.target = "payway_checkout";
    Object.entries(request.fields).forEach(([name, value]) => {
      const input = document.createElement("input");
      input.type = "hidden";
      input.name = name;
      input.value = value;
      paymentForm.appendChild(input);
    });
    document.body.appendChild(paymentForm);
    paymentForm.submit();
    paymentForm.remove();
  };

  const openHostedCheckout = async (booking?: Booking) => {
    const checkoutWindow = window.open("", "payway_checkout", "width=520,height=760");
    if (!checkoutWindow) {
      setPaymentMessage("Please allow pop-ups, then choose Continue Payment.");
      return;
    }
    checkoutWindow.document.write("<title>Opening ABA PayWay…</title><p style='font-family:Arial;padding:32px'>Preparing secure ABA PayWay checkout…</p>");
    try {
      if (!booking && checkoutRequest) {
        submitHostedForm(checkoutRequest);
        return;
      }
      const bookingToPay = booking ?? invoice ?? form;
      const response = await fetch(`${process.env.NEXT_PUBLIC_API_BASE_URL}/api/payway/purchase`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(bookingToPay),
      });
      const result = await response.json();
      if (!response.ok) throw new Error(result.message || "PayWay is not configured.");
      if (!result.action || !result.fields) throw new Error("Invalid PayWay checkout response.");
      const nextCheckout = { action: result.action as string, fields: result.fields as Record<string, string> };
      setConfirmation(result.bookingId);
      setBookingStatus(result.status || "PAYMENT_PENDING");
      setCheckoutRequest(nextCheckout);
      submitHostedForm(nextCheckout);
    } catch (error) {
      checkoutWindow.close();
      setPaymentMessage(error instanceof Error ? error.message : "Unable to start PayWay checkout.");
    }
  };

  const checkPaymentStatus = async () => {
    setPaymentMessage("Checking payment status…");
    try {
      const response = await fetch(`/api/payway/status?bookingId=${encodeURIComponent(confirmation)}`);
      const result = await response.json();
      setBookingStatus(result.status || "PAYMENT_PENDING");
      setPaymentMessage(result.message || "Payment is still pending.");
    } catch {
      setPaymentMessage("Unable to check payment status. Please try again.");
    }
  };

  const cancelBooking = async () => {
    if (bookingStatus === "PAID" || bookingStatus === "CONFIRMED") return;
    try {
      const response = await fetch("/api/payway/cancel", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ bookingId: confirmation }),
      });
      const result = await response.json();
      if (!response.ok) throw new Error(result.message || "Unable to cancel booking.");
      setBookingStatus(result.status || "CANCELLED");
      setPaymentMessage(result.message || "Booking cancelled.");
    } catch (error) {
      setPaymentMessage(error instanceof Error ? error.message : "Unable to cancel booking.");
    }
  };

  if (false) {
    return (
      <main className="authRedirect">
        <section className="authRedirectCard" aria-live="polite">
          <img src="/prathna-kasekor-khmer-logo.png" alt="PRATHNA KASEKOR KHMER IMPORT EXPORT CO., LTD." />
          <p className="eyebrow">SECURE BOOKING ACCESS</p>
          <h1>Continue with Google</h1>
          <p>Redirecting you to Google secure sign-in…</p>
          <a href="https://ptr-connect-api.onrender.com/auth/google">Continue with Google</a>
        </section>
      </main>
    );
  }

  return (
    <main>
      <header className="appHeader noPrint">
        <img className="brandArtwork" src="/prathna-kasekor-khmer-logo.png" alt="PRATHNA KASEKOR KHMER IMPORT EXPORT CO., LTD." />
        <div><p className="eyebrow">PRATHNA KASEKOR KHMER IMPORT EXPORT CO., LTD.</p><h1>Booking & Invoice</h1><p className="khmer">ប្រព័ន្ធកក់បន្ទប់ និងវិក្កយបត្រ</p></div>
        <span className="status"><i /> System ready</span>
      </header>

      <section className="workspace noPrint">
        <div className="intro"><div><span>NEW RESERVATION</span><h2>Create New Booking</h2><p>Enter guest details and charges. Your total updates automatically.</p></div><div className="totalPill"><small>BALANCE DUE</small><strong>USD {money(totals.balance)}</strong></div></div>
        <form onSubmit={makeInvoice}>
          <div className="formGrid">
            <fieldset><legend><b>01</b><span>GUEST PROFILE<small>ព័ត៌មានភ្ញៀវ</small></span></legend>
              <label>Guest name <em>ឈ្មោះភ្ញៀវ</em><input required value={form.guestName} onChange={e => update("guestName", e.target.value)} placeholder="e.g. Chang Lung Ng" /></label>
              <label>Address / Country <em>អាសយដ្ឋាន / ប្រទេស</em><input required value={form.address} onChange={e => update("address", e.target.value)} /></label>
              <label>Booking type <em>ប្រភេទការកក់</em><select value={form.bookingType} onChange={e => update("bookingType", e.target.value)}><option>Personal</option><option>Family</option><option>Company</option><option>Package Tours</option></select></label>
              {(form.bookingType === "Company" || form.bookingType === "Package Tours") && <label>Company / Tour name <em>ឈ្មោះក្រុមហ៊ុន / ទេសចរណ៍</em><input value={form.company} onChange={e => update("company", e.target.value)} placeholder="Enter organization name" /></label>}
            </fieldset>
            <fieldset><legend><b>02</b><span>RESERVATION DETAILS<small>ព័ត៌មានការកក់</small></span></legend>
              <div className="two"><label>Room number <em>លេខបន្ទប់</em><input required value={form.room} onChange={e => update("room", e.target.value)} placeholder="310" /></label><label>Guests <em>ចំនួនភ្ញៀវ</em><select value={form.guests} onChange={e => update("guests", e.target.value)}><option>1 Adult</option><option>2 Adults</option><option>Family</option></select></label></div>
              <label>Check-in <em>ថ្ងៃចូល</em><input required type="datetime-local" value={form.checkIn} onChange={e => update("checkIn", e.target.value)} /></label>
              <label>Check-out <em>ថ្ងៃចេញ</em><input required type="datetime-local" value={form.checkOut} onChange={e => update("checkOut", e.target.value)} /></label>
            </fieldset>
            <fieldset className="charges"><legend><b>03</b><span>CHARGES & PAYMENT<small>ការគិតថ្លៃ និងការទូទាត់</small></span></legend>
              <div className="three"><label>Daily accommodation rate<input required min="0" step="0.01" type="number" value={form.rate} onChange={e => update("rate", e.target.value)} /></label><label>Length of stay <em>Auto</em><input className="autoField" readOnly value={`${nights} ${nights === 1 ? "day" : "days"}`} /></label><label>Paid / Deposit<input min="0" step="0.01" max={totals.charges || undefined} type="number" value={form.deposit} onChange={e => update("deposit", e.target.value)} /></label></div>
              {form.checkIn && form.checkOut && nights === 0 && <p className="dateError">Check-out must be later than check-in.</p>}
              <div className="summary"><span>Total charges <b>USD {money(totals.charges)}</b></span><span>Paid / deposit <b>USD {money(totals.paid)}</b></span><span className="due">Balance due <b>USD {money(totals.balance)}</b></span></div>
            </fieldset>
          </div>
          <button className="primary" type="submit"><span>Confirm Booking</span><small>បញ្ជាក់ការកក់ និងបន្តទៅការទូទាត់</small><b>→</b></button>
        </form>
        {message && <div className="toast" role="status">✓ {message}</div>}
      </section>

      {invoice && invoiceTotals && <section className="invoiceWrap" id="invoice">
        <article className="invoice">
          <div className="companyHeader"><img className="invoiceCompanyLogo" src="/prathna-kasekor-khmer-logo.png" alt="PRATHNA KASEKOR KHMER IMPORT EXPORT CO., LTD." /><div><h2>PRATHNA KASEKOR KHMER IMPORT EXPORT CO., LTD.</h2><p><b>Address (EN):</b> No House Number, No Street Name, Kilometre 4 Village, Sangkat Phsar Kandal, Poipet Municipality, Banteay Meanchey Province, Cambodia</p><p className="khmer"><b>អាសយដ្ឋាន (KH):</b> ភូមិគីឡូម៉ែត្រលេខ៤ សង្កាត់ផ្សារកណ្ដាល ក្រុងប៉ោយប៉ែត ខេត្តបន្ទាយមានជ័យ</p><p><b>Email:</b> chhimrasmey82@gmail.com &nbsp;|&nbsp; <b>Tel:</b> +855 67 919 919 &nbsp;|&nbsp; <b>Website:</b> www.ptrconnect.online</p></div></div>
          <div className="invoiceTitle"><div><span>CUSTOMER INVOICE</span><small>វិក្កយបត្រអតិថិជន</small></div><div><small>CONFIRMATION NO.</small><b>{confirmation}</b></div></div>
          <div className="profileGrid"><div className="infoBox"><h3>GUEST PROFILE</h3><p><b>Guest Name:</b><span>{invoice.guestName}</span></p><p><b>Address:</b><span>{invoice.address}</span></p><p><b>Booking Type:</b><span>{invoice.bookingType}</span></p><p><b>Company / Tour:</b><span>{invoice.company || "—"}</span></p></div><div className="infoBox"><h3>RESERVATION DETAILS</h3><p><b>Room Number:</b><span>{invoice.room}</span></p><p><b>No. of Guests:</b><span>{invoice.guests}</span></p><p><b>Check-In:</b><span>{displayDate(invoice.checkIn)}</span></p><p><b>Check-Out:</b><span>{displayDate(invoice.checkOut)}</span></p><p><b>Length of Stay:</b><span>{calculateStay(invoice.checkIn, invoice.checkOut)} days</span></p><p><b>Status:</b><span className={bookingStatus === "CONFIRMED" ? "confirmed" : "pending"}>{bookingStatus.replaceAll("_", " ")}</span></p></div></div>
          <table><thead><tr><th>DATE</th><th>DESCRIPTION</th><th>CHARGES (USD)</th><th>CREDITS / PAYMENTS (USD)</th></tr></thead><tbody>{Array.from({ length: calculateStay(invoice.checkIn, invoice.checkOut) || 1 }).map((_, i) => { const date = new Date(invoice.checkIn); date.setDate(date.getDate() + i); return <tr key={i}><td>{shortDate(date.toISOString())}</td><td>Accommodation Charges — Room #{invoice.room}</td><td>{money(Number(invoice.rate))}</td><td>0.00</td></tr> })}<tr><td>—</td><td>Occupancy Tax (0.00%)</td><td>0.00</td><td>0.00</td></tr></tbody></table>
          <div className="totals"><p><span>Total Charges</span><b>{money(invoiceTotals.charges)}</b></p><p><span>Paid / Deposit</span><b>{money(invoiceTotals.deposit)}</b></p><p className="balance"><span>Balance to Pay</span><b>USD {money(Math.max(invoiceTotals.charges - invoiceTotals.deposit, 0))}</b></p></div>
          <div className="notice"><p><b>NOTICE TO GUESTS:</b> This property is privately owned and management reserves the right to refuse service. Management will not be responsible for loss of money, jewellery or valuables of any kind, or for items left in the room.</p><p><b>CHECKOUT TIME: 11:00 AM &nbsp;|&nbsp; SELF REGISTRATION ONLY</b><br/>I agree that my liability for this bill is not waived and agree to be held personally liable for all charges, including missing or damaged items.</p></div>
          <div className="signatures"><p><span />Guest Signature</p><p><span />Authorized Representative</p></div><footer>Thank you for choosing PRATHNA KASEKOR KHMER IMPORT EXPORT CO., LTD. <b>Page 1</b></footer>
        </article>
        <div className="invoiceActions bottomActions noPrint"><button onClick={() => window.print()}>Print / Save PDF</button><button onClick={() => void openHostedCheckout()}>Continue Payment</button><button className="ghost" onClick={() => void checkPaymentStatus()}>Check Payment Status</button><button className="danger" disabled={bookingStatus === "PAID" || bookingStatus === "CONFIRMED" || bookingStatus === "CANCELLED"} onClick={cancelBooking}>Cancel Booking</button><button className="ghost" onClick={() => setInvoice(null)}>Close</button></div>
        {paymentMessage && <p className="paymentMessage noPrint">{paymentMessage}</p>}
        <p className="paywayRule noPrint">Payment methods and official logos are displayed by ABA PayWay Hosted Checkout according to the merchant account settings.</p>
      </section>}
    </main>
  );
}

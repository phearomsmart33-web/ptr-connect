import assert from "node:assert/strict";
import { createHmac } from "node:crypto";
import test from "node:test";
import {
  callbackSignature,
  calculateStay,
  checkTransactionHash,
  constantTimeEqual,
  normalizeMoney,
  purchaseHash,
  utcRequestTime,
} from "../lib/payway.ts";

const secret = "sandbox-test-secret";
const referenceHmac = (message) => createHmac("sha512", secret).update(message).digest("base64");

test("formats PayWay request time in UTC", () => {
  assert.equal(utcRequestTime(new Date("2026-07-21T16:30:45.000Z")), "20260721163045");
});

test("uses the documented purchase hash field order and excludes view_type", async () => {
  const fields = {
    req_time: "20260721163045", merchant_id: "merchant", tran_id: "12345", amount: "66.00",
    items: "ITEMS", firstname: "John", lastname: "Doe", type: "purchase", payment_option: "",
    return_url: "RETURN", continue_success_url: "SUCCESS", currency: "USD", return_params: "BOOKING",
    view_type: "hosted_view",
  };
  const message = "20260721163045merchant1234566.00ITEMSJohnDoepurchaseRETURNSUCCESSUSDBOOKING";
  assert.equal(await purchaseHash(fields, secret), referenceHmac(message));
});

test("uses sorted callback fields and constant-time comparison", async () => {
  const payload = { status: "0", tran_id: "12345", apv: "654321", return_params: "BOOKING" };
  const expected = referenceHmac("654321BOOKING012345");
  const actual = await callbackSignature(payload, secret);
  assert.equal(actual, expected);
  assert.equal(constantTimeEqual(actual, expected), true);
  assert.equal(constantTimeEqual(actual, expected.slice(1)), false);
});

test("hashes Check Transaction fields in documented order", async () => {
  assert.equal(await checkTransactionHash("TIME", "MERCHANT", "TRAN", secret), referenceHmac("TIMEMERCHANTTRAN"));
});

test("calculates server-side stay and money safely", () => {
  assert.equal(calculateStay("2026-07-21T13:00", "2026-07-23T11:00"), 2);
  assert.equal(normalizeMoney("33.00"), 3300);
  assert.throws(() => calculateStay("2026-07-23", "2026-07-21"), /INVALID_STAY_DATES/);
  assert.throws(() => normalizeMoney(-1), /INVALID_AMOUNT/);
});

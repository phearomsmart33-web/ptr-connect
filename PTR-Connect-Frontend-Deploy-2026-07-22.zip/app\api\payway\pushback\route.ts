import { NextRequest, NextResponse } from "next/server";
import { callbackSignature, constantTimeEqual } from "../../../../lib/payway";
import { getPayWayConfig } from "../../../../lib/payway-config";
import { reconcileTransaction } from "../../../../lib/payway-reconcile";

export async function POST(request: NextRequest) {
  try {
    const config = getPayWayConfig();
    const payload = await request.json() as Record<string, unknown>;
    const receivedSignature = request.headers.get("x-payway-hmac-sha512") || "";
    const expectedSignature = await callbackSignature(payload, config.apiKey);
    if (!receivedSignature || !constantTimeEqual(receivedSignature, expectedSignature)) {
      return NextResponse.json({ message: "Invalid callback signature." }, { status: 401 });
    }
    const tranId = typeof payload.tran_id === "string" ? payload.tran_id : "";
    if (!tranId) return NextResponse.json({ message: "Missing transaction ID." }, { status: 400 });
    const eventHash = await callbackSignature({ ...payload, signature: receivedSignature }, config.apiKey);
    await reconcileTransaction(tranId, eventHash);
    return NextResponse.json({ received: true });
  } catch (error) {
    const code = error instanceof Error ? error.message : "PUSHBACK_FAILED";
    if (code === "BOOKING_NOT_FOUND") return NextResponse.json({ message: code }, { status: 404 });
    return NextResponse.json({ message: "Callback accepted; reconciliation will be retried." }, { status: 202 });
  }
}

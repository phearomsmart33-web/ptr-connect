import { NextRequest, NextResponse } from "next/server";
import { findBookingById, recordPaymentResult } from "../../../../lib/booking-store";
import { checkTransactionHash, utcRequestTime } from "../../../../lib/payway";
import { getPayWayConfig } from "../../../../lib/payway-config";

export async function POST(request: NextRequest) {
  try {
    const { bookingId } = await request.json() as { bookingId?: string };
    if (!bookingId) return NextResponse.json({ message: "Missing booking ID." }, { status: 400 });
    const booking = await findBookingById(bookingId);
    if (!booking) return NextResponse.json({ message: "Booking not found." }, { status: 404 });
    if (booking.booking_status === "CONFIRMED" || booking.payment_status === "PAID") {
      return NextResponse.json({ message: "A paid booking cannot be cancelled here." }, { status: 409 });
    }
    const config = getPayWayConfig();
    const reqTime = utcRequestTime();
    const hash = await checkTransactionHash(reqTime, config.merchantId, booking.tran_id, config.apiKey);
    const response = await fetch(`${config.baseUrl}/api/payment-gateway/v1/payments/close-transaction`, {
      method: "POST",
      headers: { "Content-Type": "application/json", Accept: "application/json", Referer: new URL(config.callbackUrl).origin + "/" },
      body: JSON.stringify({ req_time: reqTime, merchant_id: config.merchantId, tran_id: booking.tran_id, hash }),
    });
    const result = await response.json() as { status?: { code?: string; message?: string } };
    if (!response.ok || result.status?.code !== "00") {
      return NextResponse.json({ message: result.status?.message || "ABA could not close this transaction." }, { status: 409 });
    }
    await recordPaymentResult({
      tranId: booking.tran_id,
      payloadHash: `CANCEL-${booking.tran_id}`,
      paymentStatus: "PAYMENT_FAILED",
      bookingStatus: "CANCELLED",
    });
    return NextResponse.json({ status: "CANCELLED", message: "Booking and payment transaction cancelled." });
  } catch {
    return NextResponse.json({ message: "Unable to cancel this transaction." }, { status: 503 });
  }
}

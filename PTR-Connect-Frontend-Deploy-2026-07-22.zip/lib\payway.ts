export function utcRequestTime(date = new Date()): string {
  return date.toISOString().replace(/[-:T.Z]/g, "").slice(0, 14);
}

export function base64Utf8(value: string): string {
  return Buffer.from(value, "utf8").toString("base64");
}

export async function hmacSha512Base64(message: string, secret: string): Promise<string> {
  const key = await crypto.subtle.importKey(
    "raw",
    new TextEncoder().encode(secret),
    { name: "HMAC", hash: "SHA-512" },
    false,
    ["sign"],
  );
  const signature = await crypto.subtle.sign("HMAC", key, new TextEncoder().encode(message));
  return Buffer.from(signature).toString("base64");
}

export function constantTimeEqual(a: string, b: string): boolean {
  const left = new TextEncoder().encode(a);
  const right = new TextEncoder().encode(b);
  if (left.length !== right.length) return false;
  let difference = 0;
  for (let index = 0; index < left.length; index += 1) difference |= left[index] ^ right[index];
  return difference === 0;
}

export async function callbackSignature(payload: Record<string, unknown>, secret: string): Promise<string> {
  const message = Object.keys(payload)
    .sort((a, b) => a.localeCompare(b))
    .map((key) => {
      const value = payload[key];
      return value !== null && typeof value === "object" ? JSON.stringify(value) : String(value ?? "");
    })
    .join("");
  return hmacSha512Base64(message, secret);
}

export async function purchaseHash(
  fields: Record<string, string>,
  secret: string,
): Promise<string> {
  const order = [
    "req_time", "merchant_id", "tran_id", "amount", "items", "shipping", "ctid", "pwt",
    "firstname", "lastname", "email", "phone", "type", "payment_option", "return_url",
    "cancel_url", "continue_success_url", "return_deeplink", "currency", "custom_fields", "return_params",
  ];
  return hmacSha512Base64(order.filter((key) => key in fields).map((key) => fields[key]).join(""), secret);
}

export async function checkTransactionHash(reqTime: string, merchantId: string, tranId: string, secret: string) {
  return hmacSha512Base64(reqTime + merchantId + tranId, secret);
}

export function normalizeMoney(value: unknown): number {
  const amount = typeof value === "number" ? value : Number(value);
  if (!Number.isFinite(amount) || amount < 0) throw new Error("INVALID_AMOUNT");
  return Math.round(amount * 100);
}

export function calculateStay(checkIn: string, checkOut: string): number {
  const start = new Date(checkIn);
  const end = new Date(checkOut);
  if (!Number.isFinite(start.getTime()) || !Number.isFinite(end.getTime()) || end <= start) {
    throw new Error("INVALID_STAY_DATES");
  }
  const startDay = Date.UTC(start.getUTCFullYear(), start.getUTCMonth(), start.getUTCDate());
  const endDay = Date.UTC(end.getUTCFullYear(), end.getUTCMonth(), end.getUTCDate());
  return Math.max(1, Math.round((endDay - startDay) / 86_400_000));
}

export function safeTransactionId(now = Date.now()): string {
  return String(now) + String(crypto.getRandomValues(new Uint16Array(1))[0]).padStart(5, "0");
}
